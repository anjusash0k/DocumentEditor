
const Hero = () => {
  return (
    <div>
      <div className="w-full h-[70vh] bg-black relative">
        <div className="text-white flex p-10 ml-48">
            <div className="flex flex-col">
            <h1 className="text-[95px] flex">
            D<h1 className="text-transparent bg-clip-text bg-gradient-to-b from-blue-800 to-purple-800 mb-5">I</h1>SCOVER YOUR
            </h1> 
            <h1 className="text-3xl">
            WELL-BEING-FOCUSED
            </h1>
            <h1 className="text-6xl">
            CAREER !
            </h1>
            </div>
            <div>
            <h1 className="w-[400px] ml-60 absolute top-48 left-[700px]">
            <div className="w-12 h-2 bg-gradient-to-r from-blue-800 to-purple-800 mb-5"></div>
            Design your well-being-focused career ladder with AI-enabled solutions which are aligned with UNICEFs global framework of transferable skills.
            Design your well-being-focused career ladder with AI-enabled solutions which are aligned with UNICEFs global framework of transferable skills.
            </h1>
            </div>

        </div>
      </div>
    </div>
  )
}

export default Hero
