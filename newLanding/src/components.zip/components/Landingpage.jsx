// import React from 'react'
import Hero from './Hero'
import Nav from './nav'

const Landingpage = () => {
  return (
    <div>
      <Nav/>
      <Hero/>
      
    </div>
  )
}

export default Landingpage
