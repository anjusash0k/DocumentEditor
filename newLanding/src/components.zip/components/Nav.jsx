
import ladder from "../assets/LADDER_7s.png"
import NavButtons from "./NavButtons"
const Nav = () => {
  return (
    <div>
      <div className="w-full h-[60px] bg-black transparent text-white flex items-center pl-10 pr-10  justify-between">
        <img 
        src={ladder} 
        alt=""
        className="h-[25px] w-[150px] object-cover"
        />
        <div className="">
        <NavButtons/>
        </div>
        <div className="text-white text-sm font-semibold ml-5 border px-5 py-2 rounded-xl">Sign Up</div>
      </div>
    </div>
  )
}

export default Nav
