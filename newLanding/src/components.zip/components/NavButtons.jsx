
const NavButtons = () => {
  return (
    <div>
    
      <button className="text-white text-sm font-semibold ml-5">Home</button>
      <button className="text-white text-sm font-semibold ml-5">Product</button>
      <button className="text-white text-sm font-semibold ml-5">Program</button>
      <button className="text-white text-sm font-semibold ml-5">About Us</button>
      <button className="text-white text-sm font-semibold ml-5">Contact Us</button>


    </div>
  )
}

export default NavButtons
